# MySklad
MySklad
pip install -r requirements.txt